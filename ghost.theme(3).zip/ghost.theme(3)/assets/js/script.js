$(document).ready(function(){
  /*scroll*/
  $(".scroll").click(function(event) {
    event.preventDefault();
    $('html,body').animate({scrollTop:$(this.hash).offset().top}, 500);
  });

  /*mobile-menu*/
  $(".menu-btn").click(function(){
    $(".menu-box").toggleClass('opened');
    $(".menu-btn").toggleClass('opened');
  });

  var last_top = 0;
  $(window).scroll(function() {
    var this_top = $(this).scrollTop();
    if( this_top > last_top && this_top > 0 && $(".menu-btn").hasClass("opened") != true) {
      $(".main-navbar").addClass("hide");
    }
    else {
      $(".main-navbar").removeClass("hide");
    }
	   last_top = this_top;
   });
});
